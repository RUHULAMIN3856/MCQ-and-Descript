
"use strict"
const  express = require("express");
let app = express();
const formidable = require("formidable");

app.use(express.static(__dirname+"/public"));

app.get("/", (req,res)=>{
    res.redirect("webService.html");
});

app.post('/studentinfo',(req,res)=>{
    let dataParse = new formidable.IncomingForm();
    dataParse.parse(req,(err,fields,files)=>{
        let datas = {
            fName : fields.txtFname,
            lName: fields.txtLname,
            mobile: fields.txtMobile,
            email: fields.txtEmail,
            address: fields.txtAddress
        }

        res.send("Name :" + datas.fName + " " + datas.lName+'<br/>'+
                    "Email : " + datas.email +'<br/>' +
                    "Mobile : " + datas.mobile +'<br/>' +
                    "Address : " + datas.address
        );
        res.end();
    });
});

app.listen(3030);
